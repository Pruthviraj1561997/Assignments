﻿using System;


namespace BasicsTogether
{

    class MainClass
    {
        
        void Add(int a, int b)
        {
            int c = a + b;
            Console.WriteLine("{0} + {1} ={2} ", a, b, a + b);
        }

        void Comparison(int a, int b)
        {
            if (a > b)
                Console.WriteLine("First number is greater");
            else
                Console.WriteLine("Second number is greater");
        }
        void Swap(int a, int b)
        {
            Console.WriteLine("Before swapping");
            Console.WriteLine("X {0}", +a);
            Console.WriteLine("Y {0}", +b);
            int c;
            c = a;
            a = b;
            b = c;
            Console.WriteLine("After swapping");
            Console.WriteLine("X " + a);
            Console.WriteLine("Y " + b);
        }
        void PrintTable(int a, int b)
        {


            for (int i = a; i <= b; i++)
            {
                for (int j = 1; j <= 10; j++)
                {
                    Console.WriteLine("{0} * {1} = {2} ", i, j, i * j);

                }
                Console.WriteLine("----------------------------");
            }
        }
        static void Main()
        {
            MainClass mainClass = new MainClass();
            mainClass.Add(10, 20);
            mainClass.PrintTable(10, 20);
            mainClass.Comparison    (10, 20);
            mainClass.Swap (10, 20);
            
        }

    }
}
     