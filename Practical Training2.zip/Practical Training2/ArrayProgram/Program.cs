﻿using System;

class MainClass
{
  static int[] Arrays = new int[3];

    static void AverageArrays()
    {
        int sum = 0;
        
        
        for (int i = 0; i < Arrays.Length; i++)
        {
            sum += Arrays[i];
        }

        float average = (float)sum / Arrays.Length;

        Console.WriteLine("Average of Array elements: " + average);
    }

    static void MinimumAndMaximum()
    {
        int maximum = Arrays[0];
        int minimum = Arrays[0];
        for (int i = 0; i <= Arrays.Length - 1; i++)
        {
            if (Arrays[i] > maximum)
            {
                maximum = Arrays[i];
                Console.WriteLine("Maximum Number is {0}", maximum);
            }
            if (Arrays[i] < minimum)
            {
                minimum = Arrays[i];
                Console.WriteLine("Minimum Nubmer is {0}", minimum);
            }
        }

    }
    static void Main()
    {
        
        Console.WriteLine("Enter  Array Elements: \n");
        for (int i = 0; i < 3; i++)
        {
            //Storing value in an array
            Arrays[i] = Convert.ToInt32(Console.ReadLine());
        }
        AverageArrays();
        MinimumAndMaximum();
        

        
        
        
    }
}