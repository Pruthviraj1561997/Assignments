﻿using System;

abstract class Shape
{
    
    public abstract void Draw();
    
}

class Circle : Shape
{
    public override void Draw()
    {
        Console.WriteLine("Drawing Circle: ");
    }

}
class Square : Shape
{
    public override void Draw()
    {
        Console.WriteLine("Drawing Square: ");
    }
}

class Rectangle : Shape
{
    public override void Draw()
    {
        Console.WriteLine("Drawing Rectangle: ");
    }
}

class MainClass
{
    static void Main()
    {
        Shape[] shape = new Shape[3];
        shape[0] = new Circle();
        shape[1] = new Square();
        shape[2] = new Rectangle();

        foreach(Shape s in shape)
        {
            s.Draw();
        }
    }
}