﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Assignment
{
    public partial class Assigment : Form
    {
        string str = "Data Source=PRSQL;Initial Catalog=Pruthvi;User ID=labuser;Password=Welcome123$";
        SqlConnection sqlConn;
        public Assigment()
        {
            InitializeComponent();
            sqlConn = new SqlConnection(str);
            sqlConn.Open();
        }

        private void button_Show_Department_Click(object sender, EventArgs e)
        {
          string  strcmd = @"Select * From Department_Table";
            SqlCommand sqlcmd = new SqlCommand(strcmd, sqlConn);
            DataTable dt = new DataTable();

            //SqlDataReader dataReader = sqlcmd.ExecuteReader();
            //dt.Load(dataReader); //Connected Mode

            SqlDataAdapter dataAdapter = new SqlDataAdapter(sqlcmd);
            dataAdapter.Fill(dt);
            dgvDepartments.DataSource = dt;

        }

        private void button_Exit_Click(object sender, EventArgs e)
        {
            sqlConn.Close();
            Application.Exit();
        }
    }
}
