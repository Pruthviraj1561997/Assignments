﻿namespace Assignment
{
    partial class Assigment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvEmplyoees = new System.Windows.Forms.DataGridView();
            this.dgvDepartments = new System.Windows.Forms.DataGridView();
            this.button_Exit = new System.Windows.Forms.Button();
            this.button_Show_Department = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmplyoees)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDepartments)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvEmplyoees
            // 
            this.dgvEmplyoees.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEmplyoees.Location = new System.Drawing.Point(342, 12);
            this.dgvEmplyoees.Name = "dgvEmplyoees";
            this.dgvEmplyoees.Size = new System.Drawing.Size(240, 150);
            this.dgvEmplyoees.TabIndex = 0;
            // 
            // dgvDepartments
            // 
            this.dgvDepartments.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDepartments.Location = new System.Drawing.Point(342, 178);
            this.dgvDepartments.Name = "dgvDepartments";
            this.dgvDepartments.Size = new System.Drawing.Size(240, 150);
            this.dgvDepartments.TabIndex = 1;
            // 
            // button_Exit
            // 
            this.button_Exit.Location = new System.Drawing.Point(89, 187);
            this.button_Exit.Name = "button_Exit";
            this.button_Exit.Size = new System.Drawing.Size(75, 23);
            this.button_Exit.TabIndex = 2;
            this.button_Exit.Text = "Exit";
            this.button_Exit.UseVisualStyleBackColor = true;
            this.button_Exit.Click += new System.EventHandler(this.button_Exit_Click);
            // 
            // button_Show_Department
            // 
            this.button_Show_Department.Location = new System.Drawing.Point(89, 240);
            this.button_Show_Department.Name = "button_Show_Department";
            this.button_Show_Department.Size = new System.Drawing.Size(107, 23);
            this.button_Show_Department.TabIndex = 3;
            this.button_Show_Department.Text = "Show Departments";
            this.button_Show_Department.UseVisualStyleBackColor = true;
            this.button_Show_Department.Click += new System.EventHandler(this.button_Show_Department_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(86, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Emplyoee_Details";
            // 
            // Assigment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button_Show_Department);
            this.Controls.Add(this.button_Exit);
            this.Controls.Add(this.dgvDepartments);
            this.Controls.Add(this.dgvEmplyoees);
            this.Name = "Assigment";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmplyoees)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDepartments)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvEmplyoees;
        private System.Windows.Forms.DataGridView dgvDepartments;
        private System.Windows.Forms.Button button_Exit;
        private System.Windows.Forms.Button button_Show_Department;
        private System.Windows.Forms.Label label1;
    }
}

